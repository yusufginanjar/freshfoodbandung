

<?php $__env->startSection('content'); ?>
    
    <body id="page-products"> 
        
        <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="menus" class="mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h3>
                        <a href="/">Home</a><a href="/products">/Products</a>
                    </h3>
                </div>
                <div class="col-md-3">

                </div>
                <div class="col-md-3">
                    <form class="d-flex" action="/products">
                        <input type="text" class="form-control me-2" placeholder="search" name="search">
                    </form>
                </div>
                <div class="col-md-3">
                    <ul class="d-flex mt-2">
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="sort" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Sort
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="sort">
                              <li>
                                <form class="d-flex" action="/products">
                                    <input type="hidden" name="sort" value="name">
                                    <button type="submit" class="btn btn btn-link">A - Z</button>
                                </form>
                              </li>
                              <li>
                                  <form class="d-flex" action="/products">
                                    <input type="hidden" name="sort" value="lowest-price">
                                    <button type="submit" class="btn btn btn-link">Lowest Price</button>
                                </form>
                            </li>
                              <li>
                              <li>
                                  <form class="d-flex" action="/products">
                                    <input type="hidden" name="sort" value="highest-price">
                                    <button type="submit" class="btn btn btn-link">Highest Price</button>
                                </form>
                            </li>
                              <li>
                            </ul>
                          </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="filter" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Filter
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="filter">
                              <li> 
                                  <form class="d-flex" action="/products">
                                        <input type="hidden" name="filter" value="Premium Pork">
                                        <button type="submit" class="btn btn btn-link">Premium Pork</button>
                                  </form>
                              </li>
                              <li> 
                                  <form class="d-flex" action="/products">
                                        <input type="hidden" name="filter" value="Premium Beef">
                                        <button type="submit" class="btn btn btn-link">Premium Beef</button>
                                  </form>
                              </li>
                              <li>
                            </ul>
                          </li>
                    </ul>

                </div>
            </div>
        </div>
    </section>

    <section id="products">
        <div class="container">
            <h2>Our Products</h2>
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-lg-2 col-md-3 card-wrapper">
                        <a href="/products/<?php echo e($product->slug); ?>">
                            <div class="card">
                                <div class="img-wrapper">
                                    <img src="assets/images/<?php echo e($product->image); ?>" class="card-img-top" alt="...">
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                    <p class="card-text"><?php echo e($product->currency); ?> <?php echo e(number_format($product->price)); ?></p>
                                    <form action="<?php echo e(route('cartdetail.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value=<?php echo e($product->id); ?>>
                                        <button type="submit" class="btn btn-danger">
                                            Add to Cart
                                            </button>
                                      </form>
                                </div>
                                <div class="label">
                                    <span><?php echo e($product->badge); ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
    </section>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/products.blade.php ENDPATH**/ ?>