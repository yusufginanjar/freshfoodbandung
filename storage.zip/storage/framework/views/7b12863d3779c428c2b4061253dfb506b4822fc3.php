<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email</title>
    <style>
        body{
            background-color: rgb(255, 243, 243);
            color: rgb(18, 21, 62);
            font-family: Arial, Helvetica, sans-serif;
        }

        .container{
            margin-left: 50px;
            margin-right: 50px;
            margin-top: 40px;
            justify-content: center;
            padding: 20px;
            background-color: #efd8d8;
            border-radius: 10px;
        }

        table {
            margin: 30px 0;
            font-family: arial, sans-serif;
            border-collapse: collapse;
            max-width: 400px;
        }
        
        td, th {
            border: 1px solid #b57a79;
            text-align: left;
            padding: 8px;
        }
        
        tr:nth-child(even) {
            background-color: #e59f9e;
        }
        </style>
</head>
<body>
    <div class="container">
        <h2>Order Details:</h2>
        <p>Order Number: FFB-0<?php echo e($details['carts']->id); ?></p>
        <p>Name: <?php echo e($details['fist_name']); ?> <?php echo e($details['last_name']); ?></p>
        <p>Email: <?php echo e($details['email']); ?></p>
        <p>WhatsApp: <?php echo e($details['whatsapp']); ?></p>
        <p>Address: <?php echo e($details['address']); ?>, <?php echo e($details['province']); ?>, <?php echo e($details['country']); ?>, <?php echo e($details['postcode']); ?></p>
    
        <table>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Price</th>
            </tr>
            <?php $__currentLoopData = $details['carts']->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->product->name); ?></td>
              <td><?php echo e($item->qty); ?></td>
              <td>IDR <?php echo e(number_format($item->price)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <h3>Total: IDR <?php echo e(number_format($details['carts']->total, 2)); ?></h3>
          <p style="max-width: 400px;">Prices above do not include shipping cost. We will inform you the shipping costs via WhatsApp. Please Wait.</p>
    </div>

</body>
</html><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/emailformat.blade.php ENDPATH**/ ?>