


<?php $__env->startSection('container'); ?>
    <section class="content">
        <div class="container">
            <div class="row my-3">
                <div class="col-md-8">
                    <div class="item-blog m">
                        <h4 class="title"><?php echo e($blog->title); ?></h4>
                        <a href="/dashboard/blogs" class="btn btn-success"><span data-feather="arrow-left"></span> Back to blogs</a>
                        <a href="/dashboard/blogs/<?php echo e($blog->slug); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
                        <form action="/dashboard/blogs/<?php echo e($blog->slug); ?>" method="POST" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure want to delete this blog?')"><span data-feather="x-circle"></span> Delete</button>
                        </form>
                        <div>
                            <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" class="img-fluid my-2" alt="Responsive image">
                        </div>
                        <div>
                            <?php echo $blog->body; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

      
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/dashboard/blogs/show.blade.php ENDPATH**/ ?>