<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresh Food Bandung | Checkout </title>
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body id="checkout">
    <header>
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <div class="container-fluid d-flex justify-content-center">
                    <a class="navbar-brand" href="/">
                        <img src="assets/images/logo.png" alt="">
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <section class="steps">
        <div class="container">
            <div class="d-flex justify-content-center">
                <div class="number ">
                    1
                </div>
                <div class="number active">
                    <span class="border"></span>2
                </div>
            </div>
        </div>
    </section>

    <div class="section" id="checkout-form">
        <div class="container">
            <div class="row">
                <div class="">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="/checkout" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                        <div class="col-md-7">
                            <label for="first_name" class="form-label">First name*</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e(old('first_name')); ?>" required>
                            <label for="last_name" class="form-label">Last name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e(old('last_name')); ?>">

                            <label for="whatsapp" class="form-label">Whatsapp Number*</label>
                            <input type="text" class="form-control" id="whatsapp" name="whatsapp" value="<?php echo e(old('whatsapp')); ?>">
                            
                            <div class="mb-3 checkbox">
                                <input type="checkbox" class="form-check-input" name="not_whatsapp" id="not_whatsapp">
                                <label class="form-check-label" id="checkbox-label" for="not_whatsapp">(Alternative) I don't have WhatsApp number and want to reveice info via e-mail</label>
                            </div>

                            <label for="email" class="form-label">Email address*</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>

                            <label for="company" class="form-label">Company Name (Optional)</label>
                            <input type="text" class="form-control" id="company" name="company" value="<?php echo e(old('company')); ?>">

                            <label for="country" class="form-label">Country/Region</label>
                            <input type="text" class="form-control" id="country" name="country" value="Indonesia" value="<?php echo e(old('country')); ?>">

                            <label for="province" class="form-label">Province*</label>
                            <input type="text" class="form-control" id="province" name="province" value="<?php echo e(old('province')); ?>" required>

                            <label for="address" class="form-label">Complete Address*</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address')); ?>" required>

                            <label for="postcode" class="form-label">Postcode/ZIP</label>
                            <input type="text" class="form-control" id="postcode" name="postcode" value="<?php echo e(old('postcode')); ?>">

                            <label for="notes" class="form-label">Order Notes (optional)</label>
                            <input type="notes" class="form-control" id="notes" name="notes" value="<?php echo e(old('notes')); ?>">


                        </div>
                        <div class="col-md-5 orders">
                            <h4 class="title">Your Order</h4>
                            <h5>Products</h5>
                            <hr class="mb-4">

                            <?php $__currentLoopData = $products->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-2">
                                <h6><?php echo e($item->product->name); ?></h6>
                                <h6 class="txt-orange">IDR <?php echo e(number_format($item->subtotal, 2)); ?></h6>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <hr>
                            <div class="checkout-total mb-4">
                                <h5>Total</h5>
                                <h5 class="ms-auto ">IDR <?php echo e(number_format($products->total, 2)); ?></h5>
                            </div>

                            <p>Prices above do not include shipping cost. We will inform you the shipping costs via WhatsApp after Order process finished.</p>
                            <button type="submit" class="btn btn-danger my-4 add-cart">
                                Checkout
                                </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/checkout.blade.php ENDPATH**/ ?>