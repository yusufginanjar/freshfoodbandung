

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Halaman Products</h1>
    </div>
    <div class="table-responsive">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>    
            </div>            
        <?php endif; ?>
        <a href="/dashboard/products/create" class="btn btn-primary my-3">Add new product</a>
        <table class="table table-striped table-sm">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Company</th>
            <th scope="col">Address</th>
            <th scope="col">whatsapp</th>
            <th scope="col">Email</th>
            <th scope="col">Note</th>
            <th scope="col">Date</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>FFB-0<?php echo e($order->cart_id); ?></td>
                <td><?php echo e($order->first_name . " " . $order->last_name); ?></td>
                <td><?php echo e($order->company); ?></td>
                <td><?php echo e($order->address . ", " . $order->province . ", " . $order->country . ", " .$order->postcode); ?></td>
                <td><?php echo e($order->whatsapp); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->notes); ?></td>
                <td><?php echo e($order->created_at); ?></td>
                <td>
                    <a href="/dashboard/orders/<?php echo e($order->id); ?>" class="badge bg-info"><span data-feather="eye"></span> Detail</a>
                    <form action="/dashboard/orders/<?php echo e($order->id); ?>" method="POST" class="d-inline ">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="badge bg-danger border-0 my-2" onclick="return confirm('Are you sure this order already finished?')"><span data-feather="x-circle"></span> Finish</button>
                    </form>
                
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>