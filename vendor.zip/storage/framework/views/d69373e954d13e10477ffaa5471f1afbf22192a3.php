<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresh Food Bandung | Blogs</title>
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body id="blogs">

    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/blogs/<?php echo e($blog->slug); ?>">
                            <div class="item-blog m">
                                <h4 class="title"><?php echo e($blog->title); ?></h4>
                                <p class="date"><?php echo e($blog->published_at); ?></p>
                                <hr>
                                <p><?php echo e($blog->excerpt); ?></p>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4 sidebar">
                    <div class="container">
                        <h5 class="txt-red">Recent Posts</h5>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/blogs/<?php echo e($blog->slug); ?>"><p><?php echo e($blog->title); ?></p></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <h3>Fresh Food Bandung</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
                    <p class="mt-2">
                        visit us on:
                    </p>
                    <div class="d-flex">
                        <a href="">
                            <div class="img-wrapper">
                                <img src="assets/icons/shopee-logo.svg" alt="">
                            </div>
                        </a>
                        <a href="">
                            <div class="img-wrapper">
                                <img src="assets/icons/whatsapp-logo.svg" alt="">
                            </div>
                        </a>
                    </div>
                    <hr>
                </div>
                <div class="col-md-5">
                    <ul>
                        <a href="">
                            <li class="tiktok">@fresh_food_bandung</li>
                        </a>
                        <a href="">
                            <li class="whatsapp">+6285643773721</li>
                        </a>
                        <a href="">
                            <li class="address">Margaasih, Kab. Bandung, 40218</li>
                        </a>
                    </ul>
                </div>
                <hr>
            </div>
            <p class="text-muted d-flex justify-content-center">Copyright 2022 © Fresh Food Bandung</p>
        </div>
    </footer>

    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.js"></script>

</body>
</html><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/blog.blade.php ENDPATH**/ ?>