<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fresh Food Bandung | Blogs</title>
    <link rel="stylesheet" href="../assets/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body id="blog">
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="item-blog m">
                        <h4 class="title"><?php echo e($blog->title); ?></h4>
                        <p class="date"><?php echo e(($blog->created_at)->isoFormat('dddd D Y')); ?></p>
                        <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" class="img-fluid my-3" alt="Responsive image">
                        <?php echo $blog->body; ?>

                    </div>
                </div>
                <div class="col-md-4 sidebar">
                    <div class="container">
                        <h5 class="txt-red">Recent Posts</h5>
                        <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/blogs/<?php echo e($item->slug); ?>"><p><?php echo e($item->title); ?></p></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.js"></script>

</body>
</html><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/blog.blade.php ENDPATH**/ ?>