


<?php $__env->startSection('container'); ?>
    <section class="content">
        <div class="container">
            <div class="row my-3">
                <div class="col-md-8">
                    <h5 class="my-3">Detail Order</h5>

                    <table  class="table table-sm">
                        <thead>
                        <tr>
                          <th>Product</th>
                          <th>Quantity</th>
                          <th>Price</th>
                          <th>Sub-total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $charts->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($item->product->name); ?></td>
                          <td><?php echo e($item->qty); ?></td>
                          <td>IDR <?php echo e(number_format($item->price)); ?></td>
                          <td>IDR <?php echo e(number_format($item->subtotal)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                      </table>
                      <h5>Total: IDR <?php echo e(number_format($charts->total, 2)); ?></h5>

                    <table class="table table-sm mt-4">
                        <tbody>
                          <tr>
                            <td>Invoice No</td>
                            <td>FFB-0<?php echo e($order->cart_id); ?></td>
                          </tr>
                          <tr>
                            <td>Name</td>
                            <td><?php echo e($order->first_name . " " . $order->last_name); ?></td>
                          </tr>
                          <tr>
                            <td>Company</td>
                            <td><?php echo e($order->company); ?></td>
                          </tr>
                          <tr>
                            <td>Address</td>
                            <td><?php echo e($order->address . ", " . $order->province . ", " . $order->country . ", " .$order->postcode); ?></td>
                          </tr>
                          <tr>
                            <td>Whatsapp</td>
                            <td><?php echo e($order->whatsapp); ?></td>
                          </tr>
                          <tr>
                            <td>Email</td>
                            <td><?php echo e($order->email); ?></td>
                          </tr>
                          <tr>
                            <td>Note</td>
                            <td><?php echo e($order->notes); ?></td>
                          </tr>
                          <tr>
                            <td>Date/Time</td>
                            <td><?php echo e($order->created_at); ?></td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </section>

      
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Website\Project\2022\28. Fresh Food Bandung\Source Code\back-end1\laravel\ffb\resources\views/dashboard/orders/show.blade.php ENDPATH**/ ?>